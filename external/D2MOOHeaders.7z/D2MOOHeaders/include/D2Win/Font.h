#pragma once

enum Font
{
	D2FONT_FONT8,					//Font8
	D2FONT_FONT16,					//Font16
	D2FONT_FONT30,					//Font30
	D2FONT_FONT42,					//Font42
	D2FONT_FONTFORMAL10,			//FontFormal10
	D2FONT_FONTFORMAL12,			//FontFormal12
	D2FONT_FONT6,					//Font6
	D2FONT_FONT24,					//Font24
	D2FONT_FONTFORMAL11,			//FontFormal11
	D2FONT_FONTEXOCET10,			//FontExocet10
	D2FONT_FONTRIDICULOUS,			//FontRidiculous
	D2FONT_FONTEXOCET8,				//FontExocet8
	D2FONT_REALLYTHELASTSUCKER,		//ReallyTheLastSucker
	D2FONT_FONTINGAMECHAT,			//FontInGameChat
	NUM_FONTS,
};
