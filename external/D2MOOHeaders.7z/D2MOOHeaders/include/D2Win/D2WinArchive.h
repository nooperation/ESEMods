#pragma once

#include <Windows.h>
#include <D2BasicTypes.h>
#include <Archive.h>
#include <D2Config.h>

struct D2CellFileStrc;
