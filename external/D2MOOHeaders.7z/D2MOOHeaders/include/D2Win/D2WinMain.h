#pragma once

#include <Windows.h>

#include <cstdint>
#include <D2Constants.h>
#include <DisplayType.h>

struct D2CellFileStrc;
struct D2WinEditBoxStrc;
struct D2WinControlInitStrc;
struct D2WinControlStrc;
struct SMSGHANDLER_PARAMS;

extern POINT gMousePosition_6F8FE234;
extern int32_t dword_6F8FE254;
