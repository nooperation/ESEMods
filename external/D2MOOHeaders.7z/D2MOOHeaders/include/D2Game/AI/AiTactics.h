#pragma once

#include <Units/Units.h>


#pragma pack(push, 1)
struct UnkAiStrc1
{
	D2UnitStrc* pTarget;
	int32_t nDistance;
};
#pragma pack(pop)
