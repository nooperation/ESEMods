#pragma once

#include <QUESTS/Quests.h>

#pragma pack(1)

//Unused Gossip
struct D2Act2Quest7Strc						//sizeof 0x01
{
	uint8_t unk0x00;								//0x00
};

#pragma pack()
