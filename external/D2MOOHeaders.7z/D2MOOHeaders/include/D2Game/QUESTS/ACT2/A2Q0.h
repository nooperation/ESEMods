#pragma once

#include <QUESTS/Quests.h>

#pragma pack(1)

//Jerhyn Gossip
struct D2Act2Quest0Strc						//sizeof 0x84
{
	D2QuestGUIDStrc tPlayerGUIDs;						//0x00
};

#pragma pack()
