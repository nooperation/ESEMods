#pragma once

#include <QUESTS/Quests.h>

#pragma pack(1)

//Greiz Gossip
struct D2Act2Quest8Strc						//sizeof 0x02
{
	uint8_t unk0x00[2];						//0x00
};

#pragma pack()
