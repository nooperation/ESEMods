#pragma once

#include <QUESTS/Quests.h>

#pragma pack(1)

#pragma pack()
