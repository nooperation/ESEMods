#pragma once

#include <D2StatList.h>
#include <Units/Units.h>
#include <UNIT/SUnitDmg.h>


struct D2AuraCallbackStrc;
