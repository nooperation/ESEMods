#pragma once

#include <Units/Units.h>


struct D2AuraCallbackStrc;
