#pragma once

#include <Units/Units.h>
#include <UNIT/SUnitDmg.h>


struct D2AuraCallbackStrc;
