#pragma once

#include <Units/Units.h>
#include "MonsterRegion.h"

struct D2UnkMonCreateStrc2;

