#pragma once

#include <Units/Units.h>
#include <D2DataTbls.h>

