#pragma once

#include "CommonDefinitions.h"
#include <Drlg/D2DrlgDrlgVer.h>

struct D2DrlgStrc;
struct D2ActiveRoomStrc;
struct D2DrlgRoomStrc;
struct D2DrlgLevelStrc;
struct D2DrlgOrthStrc;
struct D2PresetUnitStrc;

#pragma pack(1)


#pragma pack()
