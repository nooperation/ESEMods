#pragma once

#include "CommonDefinitions.h"
#include <Drlg/D2DrlgDrlgVer.h>

struct D2DrlgLevelStrc;

#pragma pack(1)


#pragma pack()
