#pragma once

#include "CommonDefinitions.h"

struct D2ActiveRoomStrc;
struct D2DrlgRoomStrc;
struct D2DrlgStrc;

#pragma pack(1)


#pragma pack()
