#pragma once

#include "CommonDefinitions.h"

struct D2DrlgStrc;
struct D2DrlgLevelStrc;
struct D2LvlWarpTxt;
struct D2ActiveRoomStrc;
struct D2DrlgRoomStrc;
struct D2UnitStrc;

#pragma pack(1)


#pragma pack()
