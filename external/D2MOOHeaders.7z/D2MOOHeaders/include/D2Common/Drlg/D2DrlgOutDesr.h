#pragma once

#include "CommonDefinitions.h"

struct D2DrlgLevelStrc;

#pragma pack(1)


#pragma pack()
