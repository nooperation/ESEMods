#pragma once

#include "CommonDefinitions.h"

struct D2ActiveRoomStrc;
struct D2UnitStrc;

#pragma pack(1)



#pragma pack()
