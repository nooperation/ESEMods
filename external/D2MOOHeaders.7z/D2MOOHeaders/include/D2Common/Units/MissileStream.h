#pragma once

#include "CommonDefinitions.h"

struct D2UnitStrc;

#pragma pack(1)

struct D2MissileStreamStrc
{
	int32_t* unk0x00;							//0x00
	int32_t unk0x04;							//0x04
};

#pragma pack()
