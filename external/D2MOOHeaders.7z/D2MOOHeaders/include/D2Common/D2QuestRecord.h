#pragma once

#include "CommonDefinitions.h"

#include <D2BitManip.h>

#define NUM_QUEST_WORDS 48
