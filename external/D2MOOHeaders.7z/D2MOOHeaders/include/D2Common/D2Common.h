#pragma once

#include <D2Dll.h>
