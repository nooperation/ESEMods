#pragma once

#include <Windows.h>

HMODULE delayedD2CMPDllBaseGet();
HMODULE delayedD2LANGDllBaseGet();
HMODULE delayedFOGDllBaseGet();
