#pragma once 

#include <D2Common.h>
#include <D2BasicTypes.h>

