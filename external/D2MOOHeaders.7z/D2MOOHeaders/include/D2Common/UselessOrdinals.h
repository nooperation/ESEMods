#pragma once

#include "CommonDefinitions.h"

struct D2StatListStrc;
struct D2UnitStrc;
