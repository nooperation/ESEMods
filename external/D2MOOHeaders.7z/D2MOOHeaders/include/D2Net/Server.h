#pragma once

#include <Windows.h>
#include <Safesock.h>

#include "D2Net.h"
#include "Packet.h"
