#pragma once

#include <Windows.h>

#include "Packet.h"

//1.10f Image Base: 0x6FC00000

constexpr int32_t GAME_PORT = 4000;

