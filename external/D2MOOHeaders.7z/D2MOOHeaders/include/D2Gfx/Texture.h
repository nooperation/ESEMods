#pragma once

#include <cstdint>

#include "DrawMode.h"


struct D2GfxDataStrc;
