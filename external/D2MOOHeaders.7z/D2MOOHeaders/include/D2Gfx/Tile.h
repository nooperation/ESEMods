#pragma once

#include <cstdint>


struct D2GfxLightStrc;
struct D2TileLibraryEntryStrc;
