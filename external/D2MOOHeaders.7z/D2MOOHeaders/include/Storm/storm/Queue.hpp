#ifndef STORM_QUEUE_HPP
#define STORM_QUEUE_HPP

#include "storm/queue/TSPriorityQueue.hpp"
#include "storm/queue/TSTimerPriority.hpp"

#endif
